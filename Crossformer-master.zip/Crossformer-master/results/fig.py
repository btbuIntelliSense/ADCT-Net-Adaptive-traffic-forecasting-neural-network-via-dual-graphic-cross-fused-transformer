import numpy as np
setting = 'Crossformer_Greenhouse_jiu_il48_ol24_sl48_win2_fa10_dm256_nh4_el3_itr2'
show = np.load('./'+setting+'/metrics.npy')
pred = np.load('./'+setting+'/pred.npy')
true = np.load('./'+setting+'/true.npy')
print(pred.shape)
print(true.shape)

import matplotlib.pyplot as plt
# plt.figure()
# plt.plot(true[4,:,0:1], label='GroundTruth')
# plt.plot(pred[4,:,0:1], label='Prediction')
"""完整测试"""
save_true=true[:,0,:].reshape(-1,5)
save_pred=pred[:,0,:].reshape(-1,5)


plt.plot(true[:,0,0].reshape(-1), label='GroundTruth',color='k')
plt.plot(pred[:,0,0].reshape(-1), label='Prediction',color='r')
# plt.plot(true[:,:1,3], label='GroundTruth')
# plt.plot(pred[:,:1,3], label='Prediction')
plt.legend()
plt.show()