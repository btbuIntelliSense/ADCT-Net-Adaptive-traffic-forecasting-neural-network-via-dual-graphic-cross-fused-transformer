import numpy as np


# Root Relative Squared Error (RSE)
def RSE(pred, true):
    return np.sqrt(np.sum((true - pred) ** 2)) / np.sqrt(np.sum((true - true.mean()) ** 2))
    # return np.sqrt(np.sum((true - pred) ** 2) / np.sum((true - true.mean()) ** 2))


# def RAE(pred, true):
#     return np.sqrt(np.sum((true-pred)**2)) / np.sqrt(np.sum((true-true.mean())**2))

# def CORR(pred, true):
#     u = ((true-true.mean(0))*(pred-pred.mean(0))).sum(0)
#     d = np.sqrt(((true-true.mean(0))**2*(pred-pred.mean(0))**2).sum(0))
#     return (u/d).mean(-1)

def CORR(pred, true):
    # m, mp, sig, sigp = y.mean(axis=0), yp.mean(axis=0), y.std(axis=0), yp.std(axis=0)
    # corr = ((((y - m) * (yp - mp)).mean(axis=0) / (sig * sigp))[sig != 0]).mean()
    m, mp, sig, sigp = true.mean(axis=0), pred.mean(axis=0), true.std(axis=0), pred.std(axis=0)
    corr = ((((true - m) * (pred - mp)).mean(axis=0) / (sig * sigp))[sig != 0]).mean()
    return corr


def MAE(pred, true):
    return np.mean(np.abs(pred - true))


def MSE(pred, true):
    return np.mean((pred - true) ** 2)


def RMSE(pred, true):
    return np.sqrt(MSE(pred, true))


def MAPE(pred, true):
    return np.mean(np.abs((pred - true) / true))


def MSPE(pred, true):
    return np.mean(np.square((pred - true) / true))


def SMAPE(pred, true):
    return 2.0 * np.mean(np.abs(pred - true) / (np.abs(pred) + np.abs(true)))


def metric(pred, true):
    rse = RSE(pred, true)
    mae = MAE(pred, true)
    mse = MSE(pred, true)
    rmse = RMSE(pred, true)
    # mape = MAPE(pred, true)
    # mspe = MSPE(pred, true)
    corr = CORR(pred, true)
    smape = SMAPE(pred, true)

    # return mae,mse,rmse,rse,corr
    return rse, corr, rmse, mae, mse, smape





#
import numpy as np
#
# def RSE(pred, true):
#     return np.sqrt(np.sum((true-pred)**2)) / np.sqrt(np.sum((true-true.mean())**2))
#
# def CORR(pred, true):
#     u = ((true-true.mean(0))*(pred-pred.mean(0))).sum(0)
#     d = np.sqrt(((true-true.mean(0))**2*(pred-pred.mean(0))**2).sum(0))
#     return (u/d).mean(-1)
#
# def MAE(pred, true):
#     return np.mean(np.abs(pred-true))
#
# def MSE(pred, true):
#     return np.mean((pred-true)**2)
#
# def RMSE(pred, true):
#     return np.sqrt(MSE(pred, true))
#
# def MAPE(pred, true):
#     return np.mean(np.abs((pred - true) / true))
#
# def MSPE(pred, true):
#     return np.mean(np.square((pred - true) / true))
#
# def metric(pred, true):
#     mae = MAE(pred, true)
#     mse = MSE(pred, true)
#     rmse = RMSE(pred, true)
#     mape = MAPE(pred, true)
#     mspe = MSPE(pred, true)
#
#     return mae,mse,rmse,mape,mspe